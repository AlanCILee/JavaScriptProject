<?php
/*http://ec2-52-201-212-193.compute-1.amazonaws.com/phpmyadmin/*/
    $servername = "ec2-52-201-212-193.compute-1.amazonaws.com";
    $username = "s2016a_user18";
    $password = "s2016a_user18";
    $dbname = "s2016a_user18";
 
 
//============================  SEARCH button clicked     ==============================
if(isset($_POST["address"])){
    $address = $_POST["address"];
    }
  //  $tempAdd = $_POST["ad"];
// ===================================     DELETE button clicked     ==========================    
if(isset($_POST["del"])){
    $delete = $_POST["del"];
    $address2 = $_POST["address2"];
	}

// ===============================     IF NEW POST button is clicked     =====================================

//alertTest();
/*if(isset($_POST['newPost'])) {
   
    $address = $_POST["address"];
  	$city = $_POST["city"];
    $postal = $_POST["postal"];
    $room = $_POST["rooms"];
    $bath = $_POST["baths"];
    $descp = $_POST["description"];
    $sqft = $_POST["squareF"];
    $price = $_POST["Price"];
    $category = $_POST["cat"]; 
	}*/
/* 	$address = $_POST["address"];
	$delete = isset($_POST["del"]);
    $address2 = isset($_POST["address2"]);
*/
/*if(isset($_POST["address"])){
    $address = $_POST["address"];
    }
*/

/*use IF isset to varify blanks*/
      
  /*  
  	$city = $_POST["city"];
    $postal = $_POST["postal"];
    $room = $_POST["rooms"];
    $bath = $_POST["baths"];
    $descp = $_POST["description"];
    $sqft = $_POST["squareF"];
    $price = $_POST["Price"];
    $category = $_POST["cat"];
   */
/*
function alertTest(){
echo '<script language="javascript">';
echo 'alert("message successfully sent")';
echo '</script>';
	
}
    */
    
 // ===========================================       img input        ===========================================     


if(isset($_FILES['myfile'])){
      $errors= array();
      $file_name = $_FILES['myfile']['name'];
      $file_size =$_FILES['myfile']['size'];
      $file_tmp =$_FILES['myfile']['tmp_name'];
      $file_type=$_FILES['myfile']['type'];
     
      
      if($file_size > 2097152){
         $errors[]='File size must not exceed 2 MB';
      }
     // if $errors is EMPTY - upload the img file
      if(empty($errors)==true){
         move_uploaded_file($_FILES["myfile"]["tmp_name"],
                                "../www/" . $_FILES["myfile"]["name"]);
                                
         // echo "Uploaded File :".$_FILES["myfile"]["name"] . "<br>";

      echo "<script>document.getElementById('img').innerHTML = 'Upload successful!'</script>";
      
          $img = $_FILES['myfile']['name']; //store image path for sql upload
          
      }else{
         print_r($errors);
      }
   }
   


// ==============================     sql search by ADDRESS     ===============================


    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
		 
		 if(isset($address))
		 {
		
		 $sql = "Select propertyID, address, city, postalCode, roomCnt, bathCnt, category, description, sqFt,price, imgPath From formTest ";
		 $sql .= " where address ='" . $address . "' order by propertyID asc ";
// and EMPLOYEE NUMBER
		 $result = mysqli_query($conn, $sql) or die("Query: ($sql) [problem]");
		    $fields = mysqli_num_fields($result);

		    if (mysqli_num_rows($result) > 0) 
		    {
		        // output data of each row
		        
		        while($row = mysqli_fetch_row($result)) {
		            display("<tr>","\n");
		            for ($i=0; $i < $fields; $i++) {
		                display("<td>" , $row[$i] . "</td>");
		            }
		            display("</tr>","\n");
		        }
		    }
			else {
			        echo "<strong>0 results</strong>";
			    }
		 }
	   /* mysqli_close($conn);*/		
// ====================================    DELETE record      ==================================		
		elseif(isset($delete))
		   {
			if (!$conn) 
			{
		        die("Connection failed: " . mysqli_connect_error());
			}  
			$conn->query("Delete From formTest where propertyID = $delete");
//   WHERE CustomerName='Alfreds Futterkiste' AND ContactName='Maria Anders';		    
		    

// =======================    re-display records after DELETE    =====================
		        
		 $sql = "Select propertyID, address, city, postalCode, roomCnt, bathCnt, category, description, sqFt,price, imgPath From formTest ";
		 $sql .= " where address ='" . $address2 . "' order by propertyID asc ";
// and EMPLOYEE NUMBER

		        
		       $result = $conn->query($sql) or die("Query: ($sql) [problem]");
		 
		        if ($result->num_rows > 0) {
		            // output data of each row
		            $fields = mysqli_num_fields($result);
		            
		        if (mysqli_num_rows($result) > 0) 
				    {
				        // output data of each row
				        
				        while($row = mysqli_fetch_row($result)) {
				            display("<tr>","\n");
				            for ($i=0; $i < $fields; $i++) {
				                display("<td>" , $row[$i] . "</td>");
				            }
				            display("</tr>","\n");
				        }
				    }
				}
		           else 
		        {
			        echo "<strong>0 results</strong>";
		        }
		    } 
//================================     UPLOAD NEW POST     =================================================

		  
    		
    
 
     $conn->close();
     
//================      clear inputs and preview image once upload button is clicked      ==================================================================================
   /*   echo "<script> 
	document.getElementById('searchadd').value ='';
	document.getElementById('de').value ='';
	document.getElementById('city').value ='';
	document.getElementById('pos').value ='';
	document.getElementById('rm').value ='';
	document.getElementById('bh').value ='';
	document.getElementById('descp').value ='';
	document.getElementById('sf').value ='';
	document.getElementById('price').value ='';
	document.getElementById('file').value = '';
	</script>";*/
    
   
    // ===================     transfer display() results back to HTML  =======================
    function display($tag , $value) {
        echo $tag . $value ;
    }


?>